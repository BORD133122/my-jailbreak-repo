
window.addEventListener("load", function() { 
   //document.body.style.width='100%';
   //document.body.style.height='100%';
}, false);


var appPlaying, timer = null, isScroll = false;
var sc = '';
//var C1 = '#FFFFFF', C3 = '#8450E8', C4 = '#575CDC', C5 = '#0471D3';


function init(){
	
	checkSettings();
	
	updateClock();
	setInterval("updateClock();", 1000);
	
	move('date-cont');
	
	forecastMaker.makeForecast({
       holder: document.getElementById('forecast'),
	   color: config.C1,
       dayCount: 3, //number of days
       dayWidth: 50, //holder width can also be used as spacing
       dayHeight: 100, //holder height
       imgWidth: 40, //image size
       font: 'heavy',
       dayTop: 80, //day vertical position from top
       tempBottom: 30, //temp vertical position from bottom
       fontSize: 0.7, //day text and temp size
       iconURL: 'weather/', //url to icon
       iconsName: 'weatherIcons', //id for weather icons (increments)
       daysName: 'weatherDays', //id for days (increments)
       tempsName: 'weatherTemps', //id for temps (increments)
    });
	
	XenApi();
	
}

function openWindow(el, num){
	if(sc !== el){
		moveSel(num);
		movePad();
		move(el);
	}
}


//----------------------------- PANELS MOVE FUNCTION --------------------------------
function move(el){
	//if(config.gc){
		if(sc !== el){
			if(sc !== ''){
				removeOpen(sc);
				closePad(sc);
			}
			
			addOpen(el);
			
			openPad(el);
			
			sc = el;
		}
	//}
}

function openPad(el){
	if(el === 'wea-cont'){
		addOpen('weather-container');
	}
	
	if(el === 'mus-cont'){
		addOpen('music-container');
	}
	
	if(el === 'date-cont'){
		addOpen('time-container');
	}
}

function closePad(el){
	if(el === 'wea-cont'){
		removeOpen('weather-container');
	}
	
	if(el === 'mus-cont'){
		removeOpen('music-container');
	}
	
	if(el === 'date-cont'){
		removeOpen('time-container');
	}
}



function removeOpen(el){
	document.getElementById(el).classList.remove('open');
	setTimeout(function(){
		document.getElementById(el).style.display = 'none';
	}, 300);
}

function addOpen(el){
	document.getElementById(el).style.display = 'block';
	setTimeout(function(){
		document.getElementById(el).classList.add('open');
	}, 100);
}


function moveSel(num){
	document.getElementById("selector").style.top = num * 25 + '%';
	if(num === 1){
		document.documentElement.style.setProperty('--bgBtn', config.C3);
	}else if(num === 2){
		document.documentElement.style.setProperty('--bgBtn', config.C4);
	}else{
		document.documentElement.style.setProperty('--bgBtn', config.C5);
	}
}

function movePad(){
	document.getElementById("back-cont").style.left = '30%';
	setTimeout(function(){
		document.getElementById("back-cont").style.left = '0%';
	}, 150);
}

function openApp(app){
	api.apps.launchApplication(app);
}

