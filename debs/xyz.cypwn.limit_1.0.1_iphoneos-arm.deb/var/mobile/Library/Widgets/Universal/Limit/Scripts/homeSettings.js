
function checkSettings(){
	
	document.documentElement.style.setProperty('--primary', config.C1);
	document.documentElement.style.setProperty('--secondary', config.C2);
	document.documentElement.style.setProperty('--bgBtn', config.C3);
	document.documentElement.style.setProperty('--bgP', config.bgP);
	
	document.documentElement.style.setProperty('--bg', config.bgC);
	
	document.documentElement.style.setProperty('--br', config.br + 'px');
	document.documentElement.style.setProperty('--bl', config.bl + 'px');
	
	if(config.di){
		document.getElementById("_time").style.display = 'block';
		document.getElementById("clockCont").style.display = 'none';
	}
	
	switch (config.bg) {
		case 1:
			break;
		case 2:
			document.getElementById("container").style.background = 'none';
			document.getElementById("container").classList.add('addBlur');
			break;
		case 3:
			document.getElementById("container").classList.add('addBlur');
			break;
		case 4:
			document.getElementById("container").style.background = 'none';
			break;
	}
	
	/*if(config.ph){
		if (localStorage.getItem('vueWidget') === null) {
			
		}else{
			document.getElementById("photoImg").src = localStorage.getItem('vueWidget');
		}
		//localStorage.clear();
		
		document.documentElement.style.setProperty('--pY', config.pY + 'px');
		document.documentElement.style.setProperty('--pX', config.pX + '%');
		document.documentElement.style.setProperty('--pH', config.pH + 'px');
		document.documentElement.style.setProperty('--pW', config.pW + '%');
	}else{
		document.getElementById("photo").style.display = 'none';
	}
	
	if(!config.gc){
		document.getElementById("general-container").style.display = 'none';
	}else{
		document.documentElement.style.setProperty('--gY', config.gY + 'px');
		document.documentElement.style.setProperty('--gX', config.gX + '%');
		
		if(!config.ad){
			document.getElementById("drawer").style.display = 'none';
			document.getElementById("weather-container").classList.add('small');
			document.getElementById("music-container").classList.add('small');
		}
	}
	
	if(!config.fc){
		document.getElementById("foot-container").style.display = 'none';
	}else{
		document.documentElement.style.setProperty('--fY', config.fY + 'px');
		document.documentElement.style.setProperty('--fX', config.fX + '%');
	}*/
	
}


