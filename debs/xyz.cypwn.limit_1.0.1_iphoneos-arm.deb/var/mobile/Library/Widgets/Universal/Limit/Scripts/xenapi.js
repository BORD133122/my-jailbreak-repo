


function XenApi(){
	
	//if(config.fc){
		api.weather.observeData(function (newData) {
			checkWeather(newData);
		});
		
		api.media.observeData(function (newData) {
			appPlaying = newData.nowPlayingApplication.identifier;
			checkMusic(newData);
		});
		
		api.media.observeElapsedTime(function (newElapsedTime) {
			handleTrackTimes(newElapsedTime, api.media.nowPlaying.length, false);
		});
	//}
	
}

function checkWeather(newData){
	
	document.getElementById('cond').innerHTML = newData.now.condition.description;
	document.getElementById('temp').innerHTML = newData.now.temperature.current + 'º';
	document.getElementById('wIcon').src = 'weather/' + newData.now.condition.code + '.png';
	
	var icon, i;
    for (i = 0; i < 3; i++) { //loop through forecast and update each hour
        document.getElementById(fcastObj.day + i).innerHTML = shortdays[newData.daily[i].weekdayNumber];
        document.getElementById(fcastObj.temp + i).innerHTML = newData.daily[i].temperature.maximum + 'º - ' + newData.daily[i].temperature.minimum + 'º';
		icon = (newData.daily[i].condition.code == 3200) ? newData.now.condition.code : newData.daily[i].condition.code;
		document.getElementById(fcastObj.icon + i).src = 'weather/' + icon + '.png';
		document.getElementById(fcastObj.icon + i).classList.add('colorFilter');
    }
}








