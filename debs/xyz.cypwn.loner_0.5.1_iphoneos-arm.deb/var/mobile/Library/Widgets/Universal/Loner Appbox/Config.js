var Darkmode = true; // you want it dark?
var Blur = false; // you want it blurred?
var AppBoxHeight = "70"; // in %
var AppBoxWidth = "70"; // in %
var OSXStyle = true; // move buttons to the left
