var windowtitle = "Loner AiO"; // call the window title like you want
var Darkmode = true; // you want it dark?
var Blur = false; // you want it blurred?
var OSXStyle = true; // move buttons to the left
var AppBoxHeight = "38"; // Height of the Appbox
