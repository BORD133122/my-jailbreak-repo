var Darkmode = false; // you want it dark?
var Blur = false; // you want it blurred?
var AppBoxHeight = "30"; // in %
var AppBoxWidth = "90"; // in %
var OSXStyle = false; // move buttons to the left
