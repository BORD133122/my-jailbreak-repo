var Darkmode = true; // you want it dark?
var Blur = false; // you want it blurred?
var OSXStyle = true; // move buttons to the left
