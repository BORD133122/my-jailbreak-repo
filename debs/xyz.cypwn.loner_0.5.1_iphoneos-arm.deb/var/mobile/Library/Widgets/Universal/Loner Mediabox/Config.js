var Darkmode = true; // you want it dark?
var Blur = true; // you want it blurred?
var OSXStyle = true; // move buttons to the left
