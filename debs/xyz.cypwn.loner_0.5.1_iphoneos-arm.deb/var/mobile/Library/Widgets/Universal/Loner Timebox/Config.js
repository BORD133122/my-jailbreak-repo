var Darkmode = true; // you want it dark?
var Blur = false; // you want it blurred?
var DisableShadow = false; // disable Shadow
var TwelveHourClock = false; // you want 12hr clock?
var Padding = false; // want a padding?
var OSXStyle = true; // move buttons to the left
