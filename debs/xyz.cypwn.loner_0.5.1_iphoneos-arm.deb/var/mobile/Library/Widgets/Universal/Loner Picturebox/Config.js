var Darkmode = false; // you want it dark?
var Blur = false; // you want it blurred?
var titletitle = "☠️🏁"; // call the window title like you want
var OSXStyle = false; // move buttons to the left
var AppBoxHeight = "30"; // in %
var AppBoxWidth = "60"; // in %
var PicHeight = "115"; // in %
var PicWidth = "115"; // in %
