const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const weekDays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']

function doStuff() {
  document.getElementById('widget').style.background = config.topColor
  document.getElementById('clock-app-box').style.background = config.bottomColor

  if (!config.darkIcons) {
    document.getElementById('camera').style.filter = 'invert()'
    document.getElementById('calendar').style.filter = 'invert()'
    document.getElementById('mail').style.filter = 'invert()'
    document.getElementById('maps').style.filter = 'invert()'
  }

  document.getElementsByClassName('circle')[0].style.background = config.circleDateColor
  document.getElementById('date-info').style.color = config.dateColor
  document.getElementsByClassName('circle')[1].style.background = config.circleClockColor
  document.getElementById('clock').style.color = config.clockColor
  setInterval(() => {
    document.getElementById('date-info').textContent = `${weekDays[new Date().getDay()]} ${monthNames[new Date().getMonth()]} ${new Date().getDate()}, ${new Date().getFullYear()}`
    document.getElementById('clock').textContent = `${new Date().getHours()} : ${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
  }, 1000);
}