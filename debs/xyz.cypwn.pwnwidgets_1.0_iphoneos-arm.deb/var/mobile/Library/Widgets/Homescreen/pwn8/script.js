const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function doStuff() {
  if (config.dtDark) {
    document.getElementById('date').style.color = "black"
    document.getElementById('week-day').style.color = "black"
  }
  if (config.mediaInfoDark) {
    document.getElementById('track').style.color = "black"
    document.getElementById('artist').style.color = "black"
  }
  if (!config.btnDark) {
    document.getElementById('backwards').style.webkitFilter = "invert()"
    document.getElementById('forwards').style.webkitFilter = "invert()"
  }

  document.getElementById('media-player-container').style.backgroundColor = config.bgColor
  document.getElementById('date-info-line').style.backgroundColor = config.dtlnColor
  document.getElementById('background-border').style.borderColor = config.brdrColor
  setInterval(() => {
    document.getElementById('date').textContent = `${monthNames[new Date().getMonth()]} ${new Date().getDate()}, ${new Date().getFullYear()}`
    document.getElementById('week-day').textContent = `${weekDays[new Date().getDay()]}`
    if (api.media.isPlaying) {
      document.getElementById('track').textContent = api.media.nowPlaying.title
      document.getElementById('artist').textContent = api.media.nowPlaying.artist
    } else {
      document.getElementById('track').textContent = "No Media Playing"
      document.getElementById('artist').textContent = "No Artist"
    }
  }, 1000);
}