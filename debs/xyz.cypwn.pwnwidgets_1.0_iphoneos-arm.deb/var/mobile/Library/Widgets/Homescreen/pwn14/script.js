const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function doStuff() {
  document.getElementById('widget').style.backgroundColor = config.bgColor
  if (config.darkTxtIcns) {
    document.getElementById('calendar').style.backgroundColor = "rgba(0,0,0,0.4)"
    document.getElementById('bg-waves').style.webkitFilter = "invert()"
    for(var i = 0, size = document.getElementsByClassName('text').length; i < size ; i++){
      document.getElementsByClassName('text')[i].style.color = "#000000"
    }
  }
  setInterval(() => {
    document.getElementById('clock-time').textContent = `${(new Date().getHours() < 10) ? '0' + new Date().getHours() : new Date().getHours()}\n${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    document.getElementById('date').textContent = `${(new Date().getDate() < 10) ? '0' + new Date().getDate() : new Date().getDate()} ${monthNames[new Date().getMonth()]}`
  }, 1000);
}