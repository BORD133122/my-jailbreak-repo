const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function updateInfo() {
  
}

function doStuff() {
  if (config.darkMode) document.getElementById('widget').style.webkitFilter = "invert()"
  setInterval(() => {
    document.getElementById('clock-time').textContent = `${new Date().getHours()}\n${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
    document.getElementById('date').textContent = `${new Date().getDate()} ${monthNames[new Date().getMonth()]}`
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    if (new Date().getDay() == 3) document.getElementById('day').style.fontSize = "1.3rem"
  }, 1000);
}