function doStuff() {
  if (config.darkMode) {
    for(var i = 0, size = document.getElementsByClassName('app').length; i < size ; i++) {
      document.getElementsByClassName('app')[i].style.backgroundColor = "rgba(0,0,0,0.2)"
    }
    document.getElementById('widget').style.border = "1px solid black"
    document.getElementById('widget').style.backgroundColor = "rgba(0,0,0,0.2)"
    document.getElementById('pfp').style.border = "1px solid black"
    document.getElementById('bottom-bar').style.backgroundColor = "#000"
  }
  document.getElementById('username').textContent = config.username
  setInterval(() => {
    document.getElementById('clock-time').textContent = `${new Date().getHours()}:${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
    document.getElementById('signal').src = `stuff/icons/${api.comms.telephony.bars}.svg`
  }, 1000);
}