const monthNames = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
const weekDays = ['sunday','monday','tuesday','wednesday','thurday','friday','saturday']

function doStuff() {
  if (!config.batteryBar) {
    document.getElementById('batterybar').style.display = "none"
    document.getElementById('batterybarbg').style.display = "none"
  }
  
  if (!config.batteryPercent) document.getElementById('batterypercent').style.display = "none"

  document.getElementById('batterybar').style.background = config.batteryBarColor
  document.getElementById('batterybarbg').style.background = config.batteryBarBgColor
  document.getElementById('date').style.color = config.dateColor
  document.getElementById('day').style.color = config.dateColor
  document.getElementsByClassName('batterypercentdecorations')[0].style.color = config.batteryPercentDecColor
  document.getElementsByClassName('batterypercentdecorations')[1].style.color = config.batteryPercentDecColor
  document.getElementById('batterypercent').style.color = config.batteryPercentColor
  setInterval(() => {
    document.getElementById('date').textContent = `${monthNames[new Date().getMonth()]} ${new Date().getDate()}`
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    document.getElementById('batterybar').style.width = `${api.resources.battery.percentage}%`
    document.getElementById('batterypercent').textContent = `Battery ${api.resources.battery.percentage}%`
  }, 1000);
}