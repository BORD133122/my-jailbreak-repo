const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function doStuff() {
  document.getElementById('side-red-element').style.backgroundColor = config.sideBarColor
  if (config.lightMode) {
    document.getElementById('widget').style.backgroundColor = "#dbdad8"
    document.getElementById('battery-img').style.webkitFilter = "none"
    for(var i = 0, size = document.getElementsByClassName('text').length; i < size ; i++){
      document.getElementsByClassName('text')[i].style.color = "#000000"
    }
  }
  setInterval(() => {
    document.getElementById('date').textContent = `${(new Date().getDate() < 10) ? '0' + new Date().getDate() : new Date().getDate()} ${monthNames[new Date().getMonth()]} ${new Date().getFullYear()}`
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    if (api.resources.battery.percentage <= 10) {document.getElementById('battery-img').src = "stuff/icons/battery-1.svg"}
    if (api.resources.battery.percentage > 10 && api.resources.battery.percentage <= 35) {document.getElementById('battery-img').src = "stuff/icons/battery-2.svg"}
    if (api.resources.battery.percentage > 35 && api.resources.battery.percentage <= 80) {document.getElementById('battery-img').src = "stuff/icons/battery-3.svg"}
    if (api.resources.battery.percentage > 80) {document.getElementById('battery-img').src = "stuff/icons/battery-4.svg"}
    document.getElementById('battery-percent').textContent = `${api.resources.battery.percentage} %`
  }, 1000)
}