const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const weekDays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']

function doStuff() {
  document.getElementById('dayline').style.background = config.dayLineColor
  document.getElementById('day').style.color = config.dayColor
  document.getElementById('date').style.color = config.dateColor
  document.getElementById('clock').style.color = config.clockColor
  document.getElementById('clockbox').style.border = `0.1rem solid ${config.clockBorderColor}`
  document.getElementById('screwtopleft').style.background = config.screwColor
  document.getElementById('screwbottomright').style.background = config.screwColor
  setInterval(() => {
    document.getElementById('date').textContent = `${new Date().getDate()} ${monthNames[new Date().getMonth()]}`
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    document.getElementById('clock').textContent = `${new Date().getHours()} : ${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
  }, 1000);
}