const weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

function safariSearch() {
  var searchstr = document.getElementById('searchbar').value
  window.location = "http://www.google.com/search?q=" + searchstr
}

function doStuff() {
  setInterval(() => {
    document.getElementById('day').textContent = weekdays[new Date().getDay()]
    document.getElementById('date').textContent = `${new Date().getDate()} ${months[new Date().getMonth()]}`
  }, 1000)
}