const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
const Day31Months = ['January', 'March', 'May', 'July', 'August', 'September', 'November']

function doStuff() {
  document.getElementById('date-container').style.backgroundColor = config.bgColor
  if (config.darkTxt) {
    document.getElementById('month').style.color = "black"
    document.getElementById('day').style.color = "black"
  }
  if (config.darkDate) {document.getElementById('days').style.webkitFilter = "invert()"}
  setInterval(() => {
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    document.getElementById('month').textContent= `${monthNames[new Date().getMonth()]} ${new Date().getFullYear()}`
    document.getElementById('yesterday').textContent = `${(new Date().getDate() - 1 < 0) ? '' : new Date().getDate() - 1}`
    document.getElementById('today').textContent = `${(new Date().getDate() < 10) ? '0' + new Date().getDate() : new Date().getDate()}`
    document.getElementById('tomorrow').textContent = `${(new Date().getDate() + 1 > 31 && Day31Months.includes(monthNames[new Date().getMonth()])) ? '1' : new Date().getDate() + 1}`
    document.getElementById('tomorrow').textContent = `${(new Date().getDate() + 1 > 28 && monthNames[new Date().getMonth()] == "February") ? '1' : new Date().getDate() + 1}`
  }, 1000);
}