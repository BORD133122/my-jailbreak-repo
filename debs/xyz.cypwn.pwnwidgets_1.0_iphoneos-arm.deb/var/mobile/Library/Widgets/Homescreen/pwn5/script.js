const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function updateInfo() {
  const topBottomInfolmnts = document.getElementsByClassName('info-text-top-bottom')
  const weekday = document.getElementById('weekday')
  const weathericon = document.getElementById('weather-icon')

  var hour = new Date().getHours()
  var minute = new Date().getMinutes()
  var day = new Date().getDay()
  var date = new Date().getDate()
  var month = new Date().getMonth()
  var year = new Date().getFullYear()

  topBottomInfolmnts[0].textContent = `${hour}:${minute}`
  weekday.textContent = `${weekDays[day]}`
  topBottomInfolmnts[1].textContent = `${date} ${monthNames[month]} ${year}`
}

function applyStyles() {
  const clocklmnt = document.getElementsByClassName('info-text-top-bottom')[0]
  const datelmnt = document.getElementsByClassName('info-text-top-bottom')[1]
  const daylmnt = document.getElementById('weekday')
  const weatherborderlmnt = document.getElementById('weather')
  const lines = document.getElementsByClassName('line')

  clocklmnt.style.color = config.clockColor
  datelmnt.style.color = config.dateColor
  daylmnt.style.color = config.dayColor
  daylmnt.style.background = config.dayBgColor
  weatherborderlmnt.style.border = `0.15rem solid ${config.weatherColor}`
  lines[0].style.background = config.clockLineColor
  lines[1].style.background = config.dateLineColor
}

function doStuff() {
  updateInfo()
  applyStyles()
  setInterval(updateInfo, 10000)
}