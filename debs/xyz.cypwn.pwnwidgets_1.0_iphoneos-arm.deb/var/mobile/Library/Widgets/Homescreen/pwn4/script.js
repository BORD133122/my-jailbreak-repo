const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function doStuff() {
  document.getElementById('day').style.color = config.dayColor
  document.getElementById('clock').style.color = config.clockColor
  document.getElementById('widget').style.border = `0.125rem solid ${config.borderColor}`
  document.getElementById('screwtopleft').style.background = config.screwColor
  document.getElementById('screwbottomright').style.background = config.screwColor
  setInterval(() => {
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
    document.getElementById('clock').textContent = `${new Date().getHours()} : ${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
  }, 1000);
}