const weekDays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

function doStuff() {
  if (config.darkMode) {
    document.getElementById('circle').style.backgroundColor = "#416288"
    document.getElementById('date-day-box').style.backgroundColor = "rgba(0,0,0,0.3)"
  }
  setInterval(() => {
    document.getElementById('clock-time').textContent = `${new Date().getHours()}\n${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
    document.getElementById('date').textContent = `${new Date().getDate()}`
    document.getElementById('day').textContent = `${weekDays[new Date().getDay()]}`
  }, 1000);
}