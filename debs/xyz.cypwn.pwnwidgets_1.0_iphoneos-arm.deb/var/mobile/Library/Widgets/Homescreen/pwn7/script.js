function doStuff() {
  for(var i = 0, size = document.getElementsByClassName('circles').length; i < size ; i++){
    document.getElementsByClassName('circles')[i].style.color = `linear-gradient(90deg, ${config.circleGradeStartColor}, ${config.circleGradeEndColor})`
  }
  document.getElementById('widget').style.background = config.bgColor
  document.getElementsByClassName('info-identifier')[0].style.color = config.timeColor
  document.getElementById('clock').style.color = config.timeColor
  document.getElementsByClassName('info-identifier')[1].style.color = config.batteryColor
  document.getElementById('battery').style.color = config.batteryColor
  document.getElementsByClassName('info-identifier')[2].style.color = config.temperatureColor
  document.getElementById('temperature').style.color = config.temperatureColor
  setInterval(() => {
    document.getElementById('clock').textContent = `${new Date().getHours()} : ${(new Date().getMinutes() < 10) ? '0' + new Date().getMinutes() : new Date().getMinutes()}`
  }, 1000);
}